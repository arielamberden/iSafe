﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acquirer
{
    public partial class Form1 : Form
    {
        bool wasApproved = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'issuerDataSet.account' table. You can move, or remove it, as needed.
            this.accountTableAdapter.Fill(this.issuerDataSet.account);
            // TODO: This line of code loads data into the 'acquirerDataSet.checking' table. You can move, or remove it, as needed.
            this.checkingTableAdapter.Fill(this.acquirerDataSet.checking);
            // TODO: This line of code loads data into the 'acquirerDataSet.trnaction' table. You can move, or remove it, as needed.
            this.trnactionTableAdapter.Fill(this.acquirerDataSet.trnaction);
            // TODO: This line of code loads data into the 'acquirerDataSet.creditcard' table. You can move, or remove it, as needed.
            this.creditcardTableAdapter.Fill(this.acquirerDataSet.creditcard);
            // TODO: This line of code loads data into the 'acquirerDataSet.merchant' table. You can move, or remove it, as needed.
            this.merchantTableAdapter.Fill(this.acquirerDataSet.merchant);
            // TODO: This line of code loads data into the 'acquirerDataSet.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.acquirerDataSet.customer);
            // TODO: This line of code loads data into the 'acquirerDataSet.address' table. You can move, or remove it, as needed.
            this.addressTableAdapter.Fill(this.acquirerDataSet.address);
            // TODO: This line of code loads data into the 'acquirerDataSet.user' table. You can move, or remove it, as needed.
            this.userTableAdapter.Fill(this.acquirerDataSet.user);
        }

        private void userBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void userBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.userBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.acquirerDataSet);
        }

        private void Authorize_Click(object sender, EventArgs e)
        {
            //get the currently selected user from the userBindingSource.
            MessageBox.Show(((DataRowView)this.userBindingSource.Current)["fName"].ToString());
            string fname = (((DataRowView)this.userBindingSource.Current)["fName"].ToString());
            MessageBox.Show(((DataRowView)this.userBindingSource.Current)["lName"].ToString());
            string lname = (((DataRowView)this.userBindingSource.Current)["lName"].ToString());
            string amount = "";

            //customer information
            string cfname, clname, balance = "";

            try
            {
                MessageBox.Show(((DataRowView)this.trnactionBindingSource.Current)["amount"].ToString());
                amount = (((DataRowView)this.trnactionBindingSource.Current)["amount"].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("No transaction for this user.");
            }

            string connStr = "server=localhost;user id=root;password=iSafePW11;persistsecurityinfo=True;database=issuer";
            MySqlConnection conn = new MySqlConnection(connStr);

            try
            {
                Console.WriteLine("Connecting to issuing bank...");
                conn.Open();
                string sql = "SELECT fName, lName, avlLimit FROM cardholder As c INNER JOIN account AS a ON c.ID = a.ID";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {   //check the first and last name of the customer
                    if (fname == rdr[0].ToString() && lname == rdr[1].ToString())
                    {
                        Console.WriteLine(rdr[0] + " -- " + rdr[1] + " -- " + rdr[2]);
                        cfname = rdr[0].ToString();
                        clname = rdr[1].ToString();
                        balance = rdr[2].ToString();
                    }
                }

                rdr.Close();
                Console.WriteLine(Convert.ToDouble(amount));
                Console.WriteLine(balance);
                //check if customer has enough funds in account
                if ((Convert.ToDouble(amount) > Convert.ToDouble(balance)))
                    MessageBox.Show("Transaction denied.  Not enough funds in account.");
                else
                {
                    MessageBox.Show("Transaction approved.");
                    wasApproved = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            conn.Close();
            Console.WriteLine("Done.");
        }

        private void Clearing_Click(object sender, EventArgs e)
        {
            /*exchange financial transaction details between an acquirer and an issuer to facilitate 
            posting of a cardholder's account and reconciliation of a customer's settlement position.*/

            if (wasApproved == true)
            {
                //send token information from Issuer to Acquirer
            }

        }
    }
}
